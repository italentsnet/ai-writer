## Cloning & running

1. Create a `.env` (use the `.example.env` for reference) and replace the API keys
2. Run `npm install --legacy-peer-deps` and `npm run dev` to install dependencies and run locally
